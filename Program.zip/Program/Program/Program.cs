﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program
{
    class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("OPTIONS:");
            Console.WriteLine("1 - Add Book");
            Console.WriteLine("2 - View Books");
            Console.WriteLine("3 - Exit Program");
            bool run = true;
            while (run)
            {
                Console.Write("Please enter an option: ");
                int option = Convert.ToInt32(Console.ReadLine());
                BookManager bookObj = new BookManager();
                switch (option)
                {
                    case 1: //Add Book
                        Console.Write("Please enter Book Name to add: ");
                        string Name = Console.ReadLine();
                        Console.Write("Please enter Price to add: ");
                        string Price = Console.ReadLine();

                        Book bookDetails = new Book(0, Name, Convert.ToInt32(Price));
                        int returnId = bookObj.AddBook(bookDetails);
                        if (returnId != -1)
                            Console.WriteLine($"Book added successfully. Category Id: {returnId}");
                        break;

                    case 2: //View Book
                        Console.Write("Please enter the Book Name to View Number Of books available: ");
                        string bookName = Console.ReadLine();
                        int numberOfBooks = bookObj.ViewBooks(bookName);
                        if (numberOfBooks > 0)
                            Console.WriteLine($"Total Number of Books available are : " + numberOfBooks);
                        else
                            Console.WriteLine("No Books available with this Category");
                        break;

                    case 3: //Exit Program
                        run = false;
                        Console.WriteLine("Exit Program");
                        break;

                    default:
                        Console.WriteLine("Invalid Option");
                        break;
                }
            }
        }
    }
}
