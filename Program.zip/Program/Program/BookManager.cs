﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program
{
    class BookManager : IBookManager
    {
        public int AddBook(IBook e)
        {
            string conStr = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=DemoAppDB";
            SqlConnection connection = new SqlConnection(conStr);
            SqlCommand command = new SqlCommand();
            command.Connection = connection;
            command.CommandType = CommandType.StoredProcedure;
            command.CommandText = "addBook"; //Procedure
            connection.Open();

            SqlParameter parameter = new SqlParameter("@Id", 0);
            parameter.Direction = ParameterDirection.Output;
            SqlParameter parametervalues = new SqlParameter("@Name", e.Name);
            SqlParameter parameter1 = new SqlParameter("@price", e.Price);

            
            command.Parameters.Add(parametervalues);
            command.Parameters.Add(parameter1);

            command.Parameters.Add(parameter);

            int rowAffected = command.ExecuteNonQuery();
            if (rowAffected == 2)
                return Convert.ToInt32(parameter.Value);
            else
                return -1;
        }

        public int ViewBooks(string name)
        {
            int book = 0;
            string conStr = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=DemoAppDB";
            SqlConnection connection = new SqlConnection(conStr);
            SqlCommand command = new SqlCommand();
            command.Connection = connection;
            command.CommandType = System.Data.CommandType.StoredProcedure;
            command.CommandText = "viewBooksByName"; //Procedure
            connection.Open();
           
            SqlParameter parameter = new SqlParameter("@CategoryName", name);
            command.Parameters.Add(parameter);
            SqlDataReader reader = command.ExecuteReader(); //Execute select statement
            while (reader.Read())
            {
                book = Convert.ToInt32(reader["TotalNumberOfBooks"]);
            }
            return book;
        }

    }
}
