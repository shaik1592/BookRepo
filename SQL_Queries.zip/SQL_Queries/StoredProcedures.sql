
--Step -1
create table BookCategory
(Id int primary key identity,
CategoryName varchar(20))

select * from BookCategory

--Step-2
create table Book
(Id int primary key identity,
Name varchar(50),
Category int FOREIGN KEY REFERENCES BookCategory(Id),
price int)

select * from Book


--Sample data to insert---
Insert into BookCategory values('Programming')
Insert into BookCategory values('Cloud Computing')
Insert into BookCategory values('Machine Learning')

Insert into Book values('Rohith',(select Id from BookCategory where CategoryName = 'Programming'), 2000)
Insert into Book values('Javed',(select Id from BookCategory where CategoryName = 'Clod Computing'), 1000)
Insert into Book values('Ram',(select Id from BookCategory where CategoryName = 'Machine Learning'), 4000)
--End of sample data insert---


--step-3
Create PROCEDURE bookPriceandTotal
AS
  BEGIN
    select	count(Id) as TotalNumberOfBooks from Book;
	select BC.CategoryName,B.price from Book as B 
	Inner Join BookCategory BC ON BC.Id = B.Category;
  END

  EXEC bookPriceandTotal




--step-4
Create PROCEDURE updateBookPrice (@Id INTEGER, @price INTEGER)
AS
  BEGIN
     Update Book set price = @price where Id = @Id
  END

  EXEC updateBookPrice 1, 5000




--Step-5 
--Adding Book to table
Create procedure addBook
(@Name varchar(60),
@price int,
@Id int output)
As
Begin
insert into BookCategory values(@Name);
Insert into Book values(@Name,(select Id from BookCategory where CategoryName = @Name),@price);
Set @Id = (select top 1 Id from BookCategory where CategoryName = @Name order by 1 desc);
End

exec addBook 'Network', 6200,0




--Step 6
create proc viewBooksByName
(@CategoryName varchar(60))
As
Begin
select Count(Id) As TotalNumberOfBooks from BookCategory where CategoryName = @CategoryName
End

exec viewBooksByName 'Science'